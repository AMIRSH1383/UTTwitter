#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"
#define ZERO 0
#define ONE 1
#define true 2
char *commandReader(void)
{
    int command_line_length = ZERO; /*This variable is used to show us how much space should we allocate for the command string.*/
    char *command_line = (char *)malloc(sizeof(char));
    *(command_line) = '0';
    char temp_char[ONE] = {' '};
    while (true)
    {
        temp_char[ZERO] = getchar(); /*Getchar returns one character that was read from buffer.*/
        command_line_length++;
        command_line = (char *)realloc(command_line, sizeof(char) * command_line_length);/*Allocating space one character by one.*/
        command_line[command_line_length - ONE] = '\0';                                                 /*First,we make the house that we allocate from memory null in order to hae a null at the end of our string.*/
        if (temp_char[ZERO] == ' ' || !strcmp(command_line, "info") || !strcmp(command_line, "logout")) /*If command was info and logout which are one part commands we can use enter in our command.*/
        {
            return command_line;
        }
        if (temp_char[ZERO] != ' ' && temp_char[ZERO] != '\n')
        {
            command_line[command_line_length - ONE] = temp_char[ZERO]; /*This part adds one to one characters to the dynamic array called command_line.*/
        }
        if (temp_char[ZERO] == '\n' && strcmp(command_line, "info") && strcmp(command_line, "logout")) /*If command was entered wrong and there was space between sections we show an error and ask user to reenter entries.*/
        {
            printf("Syntax error please write your command correctly\n");
            return NULL;
        }
    }
}