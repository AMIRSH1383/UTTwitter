#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"
#define ZERO 0
#define ONE 1
#define true 2
int main(void)
{
    int loginFlag = 0;/*This variable shows us whether we are in an account or not.*/
    char *usernameOfCurrentUser;
    char *passwordOfCurrentUser;
    users *headOfUsers = usersHeadMaker();/*We make a head of users which is a dummy house.*/
    users *NewUser = headOfUsers;
    post *headOfPosts = postsHeadMaker();/*We make a head of posts which is a dummy house.*/
    post *NewPost = headOfPosts;
    while (true)/*Because our program never ends we use a never ending loop.*/
    {
        while (loginFlag == ZERO)/*If no one is in an account now we go through this loop and ask user to sign up or login.*/
        {
            printf("Please log in to your account.If you do not already have an account sign up.\n");
            char *commandType = commandReader();/*This function reads from buffer until it arrives to space and return the command as char pointer.*/
            if (commandType != NULL)
            {
                if (!strcmp(commandType, "signup"))/*Check if command was signup.*/
                {
                    NewUser = signup(headOfUsers, NewUser);
                }
                if (!strcmp(commandType, "login"))/*check if command was login.*/
                {
                    usernameOfCurrentUser = login(headOfUsers, &loginFlag, &passwordOfCurrentUser);
                }
                if (strcmp(commandType, "login") && strcmp(commandType, "signup"))/*If command was non of login and signup we show an error.*/
                {
                    printf("Wrong command.\n");
                }
                free(commandType);
                fflush(stdin);
            }
        }
        while (loginFlag == ONE)/*If login happened and someone is already in his/her account we go through this loop.*/
        {
            printf("Choose your action between post,like,delete,info,find_user and logout:\n");
            char *commandType = commandReader();
            if (commandType != NULL)
            {
                if (!strcmp(commandType, "logout"))/*if we read logoout from user we make login flag zero and turn back to the previous loop. */
                {
                    loginFlag = ZERO;
                }
                if (!strcmp(commandType, "post"))
                {
                    NewPost = postCreator(headOfPosts, NewPost, usernameOfCurrentUser);
                }
                if (!strcmp(commandType, "info"))
                {
                    info(headOfPosts, usernameOfCurrentUser, passwordOfCurrentUser);
                }
                if (!strcmp(commandType, "find_user"))
                {
                    find_user(headOfUsers, headOfPosts);
                }
                if (!strcmp(commandType, "delete"))
                {
                    NewPost = delete (headOfPosts, usernameOfCurrentUser, NewPost);
                }
                if (!strcmp(commandType, "like"))
                {
                    like(headOfPosts, usernameOfCurrentUser);
                }
                if (strcmp(commandType, "like") && strcmp(commandType, "delete") && strcmp(commandType, "find_user") && strcmp(commandType, "info") && strcmp(commandType, "post") && strcmp(commandType, "logout"))
                {
                    printf("Wrong command.\n");
                }
            }
            fflush(stdin);/*Cleaning the buffer in order to do not have any thing in stdin.*/
            FILE *accounts;
            accounts = fopen("accounts.txt", "w");
            users *fileInfo = headOfUsers->next;
            while (fileInfo != NULL)
            {
                post *postInfo = headOfPosts->next;
                int numberOfPosts = ZERO;
                while (postInfo != NULL)
                {
                    if (!strcmp(postInfo->owner, fileInfo->username))
                    {
                        numberOfPosts++;
                    }
                    postInfo = postInfo->next;
                }
                fprintf(accounts, "%s %s %d\n", fileInfo->username, fileInfo->password, numberOfPosts);
                fileInfo = fileInfo->next;
            }
            fclose(accounts);
            FILE *posts;
            posts = fopen("posts.txt", "w");
            fileInfo = headOfUsers->next;
            while (fileInfo != NULL)
            {
                post *postInfo = headOfPosts->next;
                while (postInfo != NULL)
                {
                    if (!strcmp(postInfo->owner, fileInfo->username))
                    {
                        fprintf(posts, "%s %s %d\n", postInfo->postContent, postInfo->owner, postInfo->like);
                    }
                    postInfo = postInfo->next;
                }
                fileInfo = fileInfo->next;
            }
            fclose(posts);
        }
    }
}