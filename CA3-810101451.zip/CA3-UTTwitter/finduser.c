#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"
#define ZERO 0
#define ONE 1
#define true 2
char *find_userReader(void)
{
    int searchedUser_length = ZERO;
    char *searchedUser = (char *)malloc(sizeof(char));
    *(searchedUser) = '0';
    char temp_char[1] = {' '};
    while (true)
    {
        temp_char[ZERO] = getchar();
        searchedUser_length++;
        if (searchedUser_length == ONE && temp_char[ZERO] == '\n') /*Extra space and enters are illegal.*/
        {
            return NULL;
        }
        if (searchedUser_length == ONE && temp_char[ZERO] == ' ')
        {
            return NULL;
        }
        searchedUser = (char *)realloc(searchedUser, sizeof(char) * searchedUser_length);
        searchedUser[searchedUser_length - ONE] = '\0';
        if (temp_char[ZERO] == '\n')
        {
            return searchedUser;
        }
        if (temp_char[ZERO] == ' ') /*Command has two sections not more.*/
        {
            return NULL;
        }
        if (temp_char[ZERO] != '\n')
        {
            searchedUser[searchedUser_length - ONE] = temp_char[ZERO];
        }
    }
}
int find_user(users *headOfUsers, post *headOfPosts)
{
    char *searchedUser = find_userReader();
    if (searchedUser == NULL)
    {
        printf("Wrong entry.Try again.\n");
        return -1;
    }
    users *checkUsername = headOfUsers->next;
    while (checkUsername != NULL)
    {
        if (!strcmp(checkUsername->username, searchedUser))/*Checking whether there is a user with this username or not.*/
        {
            printf("Username:%s\n", searchedUser);
            post *postsOfSearchedUser = headOfPosts->next;
            while (postsOfSearchedUser != NULL)
            {
                if (!strcmp(postsOfSearchedUser->owner, searchedUser))/*Checking if that user has post in order to show them.*/
                {
                    printf("Post content:%s\n", postsOfSearchedUser->postContent);
                    printf("Post ID:%d\tNumber of likes:%d\n", postsOfSearchedUser->post_id, postsOfSearchedUser->like);
                }
                postsOfSearchedUser = postsOfSearchedUser->next;
            }
            break;
        }
        if (checkUsername->next == NULL)
        {
            printf("No user found.\n");
            break;
        }
        checkUsername = checkUsername->next;
    }
    if (searchedUser != NULL)
    {
        free(searchedUser);
    }
}