#include <stdio.h>
#include <stdlib.h>
#include "structs.h"
#include <string.h>
#define ZERO 0
#define ONE 1
#define true 2
char *username_reader(void)
{
    int username_length = ZERO;
    char *username = (char *)malloc(sizeof(char));
    *(username) = '0';
    char temp_char[ONE] = {'\0'};
    while (true)
    {
        temp_char[ZERO] = getchar();
        username_length++;
        if (username_length == ONE && temp_char[ZERO] == ' ')/*Extra spaces betwwen signup/login command and username is not legal.*/
        {
            free(username);
            return NULL;
        }
        username = (char *)realloc(username, sizeof(char) * username_length);
        username[username_length - ONE] = '\0';
        if (temp_char[ZERO] == ' ')
        {
            return username;
        }
        if (temp_char[ZERO] == '\n')/*Using enter after typing username is not legal.*/
        {
            free(username);
            return NULL;
        }
        if (temp_char[ZERO] != ' ' && temp_char[ZERO] != '\n')
        {
            username[username_length - ONE] = temp_char[ZERO];
        }
    }
}
char *password_reader(void)
{
    int password_length = ZERO;
    char *password = (char *)malloc(sizeof(char));
    *(password) = '0';
    char temp_char[ONE] = {'\0'};
    while (true)
    {
        temp_char[ZERO] = getchar();
        password_length++;
        if (password_length == ONE && temp_char[ZERO] == ' ')/*Extra spaces betwwen signup/login command and password is not legal.*/
        {
            free(password);
            return NULL;
        }
        if (password_length == ONE && temp_char[ZERO] == '\n')/*Extra enter before writing the password is illegal.*/
        {
            free(password);
            return NULL;
        }
        password = (char *)realloc(password, sizeof(char) * password_length);
        password[password_length - ONE] = '\0';
        if (temp_char[ZERO] == '\n')
        {
            return password;
        }
        if (temp_char[ZERO] == ' ')/*Signup and login command are 3 sections command and 4 section is wrong.*/
        {
            free(password);
            return NULL;
        }
        if (temp_char[ZERO] != ' ' && temp_char[ZERO] != '\n')
        {
            password[password_length - ONE] = temp_char[ZERO];
        }
    }
}
users *signup(users *headOfUsers, users *NewUser)
{
    users *checkDifference = headOfUsers->next; /*This temporary struct help us to check whether username chosen by user was uses already or not.*/
    char *userName = username_reader();/*Reading the username one character by one.*/
    if (userName == NULL)/*If there was a problem in entry we show an error.*/
    {
        printf("Wrong entry.Try again with the correct command\n");
        return NewUser;
    }
    char *password = password_reader();
    if (password == NULL)
    {
        printf("Wrong entry.Try again with the correct command\n");
        return NewUser;
    }
    while (checkDifference != NULL)
    {
        if (!strcmp(checkDifference->username, userName))/*If the username has been chosen by another user before we do not make an account and we ask user to make another different username.*/
        {
            printf("This username has already been chosen.Please try another one.\n");
            free(userName);
            free(password);
            return NewUser;
        }
        else
        {
            checkDifference = checkDifference->next;
        }
    }
    NewUser->next = (users *)malloc(sizeof(users));/*Making link list with users username and passwords.*/
    NewUser = NewUser->next;
    NewUser->next = NULL;
    int userNameLen = strlen(userName);
    NewUser->username = (char *)malloc(userNameLen * sizeof(char));
    strcpy(NewUser->username, userName);
    int passwordLen = strlen(password);
    NewUser->password = (char *)malloc(passwordLen * sizeof(char));
    strcpy(NewUser->password, password);
    printf("signed up successfully.\n");
    free(userName);/*Free username and password in order to free extra space.*/
    free(password);
    return NewUser;/*Giving back the newuser pointer for the next made accounts.*/
}
char *login(users *headOfUsers, int *loginFlag, char **passwordOfCurrentUser)
{
    char *userName = username_reader();
    if (userName == NULL)
    {
        printf("Wrong entry.Try again with the correct command\n");
        return userName;
    }
    char *password = password_reader();
    if (password == NULL)
    {
        printf("Wrong entry.Try again with the correct command\n");
        return userName;
    }
    *passwordOfCurrentUser = password;
    users *check_username_and_password = headOfUsers->next; /*This temporary struct is used to check if there is an account with this specific username and password and if there is we login if not we tell user ther is a problem in login.*/
    while (check_username_and_password != NULL)
    {
        if (!strcmp(check_username_and_password->username, userName))
        {
            if (!strcmp(check_username_and_password->password, password))/*Both username and password should be correct to give permission to enter the account.*/
            {
                printf("Successfully logined\n");
                (*loginFlag) = ONE;/*If login was successful we add one to login flag.*/
                return userName;
            }
            else
            {
                printf("Your password is wrong.Try again!\n");
                break;
            }
        }
        check_username_and_password = check_username_and_password->next;
    }
    /*If user was not logined successfully username or password may be invalid.*/
    printf("Your username or password is invalid!\n");
    free(userName);
    free(password);
    return NULL;
}