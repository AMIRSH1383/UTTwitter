#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"
#define ZERO 0
#define ONE 1
#define true 2
post *delete(post *headOfPosts, char *usernameOfCurrentUser,post*NewPost)
{
    int deletingPost = ZERO;
    scanf("%d", &deletingPost);
    post *postsOfCurrentUser = headOfPosts->next;
    while (postsOfCurrentUser != NULL)
    {
        if ((!strcmp(headOfPosts->next->owner, usernameOfCurrentUser)) && headOfPosts->next->post_id == deletingPost && headOfPosts->next->next == NULL)/*If there was only one post and we wanted to delete it.*/
        {
            headOfPosts->next = postsOfCurrentUser->next;
            free(postsOfCurrentUser);
            return headOfPosts;
        }
        if ((!strcmp(headOfPosts->next->owner, usernameOfCurrentUser)) && headOfPosts->next->post_id == deletingPost && headOfPosts->next->next != NULL)/*If there was more than one post and we wanted to delte the first one.*/
        {
            headOfPosts->next = postsOfCurrentUser->next;
            free(postsOfCurrentUser);
            return NewPost;
        }
        if ((!strcmp(postsOfCurrentUser->next->owner, usernameOfCurrentUser)) && postsOfCurrentUser->next->post_id == deletingPost && postsOfCurrentUser->next->next == NULL)/*If we wanted to delete the last post.*/
        {
            post *help = postsOfCurrentUser->next;
            postsOfCurrentUser->next = postsOfCurrentUser->next->next;
            if (help != NULL)
            {
                free(help);
            }
            return postsOfCurrentUser;
        }
        if ((!strcmp(postsOfCurrentUser->next->owner, usernameOfCurrentUser)) && postsOfCurrentUser->next->post_id == deletingPost && postsOfCurrentUser->next->next != NULL)/*If we wanted to delete the post which is neither the first nor the last.*/
        {
            post *help = postsOfCurrentUser->next;
            postsOfCurrentUser->next = postsOfCurrentUser->next->next;
            free(help);
            return NewPost;
        }
        postsOfCurrentUser = postsOfCurrentUser->next;
    }
}